a=int(input(" so nguoi can nhap la: "))
for i in range(0,a):
    n_i=str(input("nhap ten: "))
print(n_i)
